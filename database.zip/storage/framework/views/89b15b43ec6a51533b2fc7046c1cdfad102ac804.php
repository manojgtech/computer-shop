<?php $__env->startSection('content'); ?>

<div class="container">
    <section>
        <div class="row">
            <?php if(count($featured_products)): ?>
done

            <?php endif; ?>
        </div>
    </section>
    <section>
        <div class="row">
        <h2 class="text-info">Categories</h2>
            <?php if(count($cats)): ?>
              <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 card">
                    <h3 card-header><?php echo e($cat->name, false); ?><h3>
                </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        </div>
    </section>
    <hr>
    <section>
        <div class="row">
            <h2 class="text-info">Brands</h2>
            <?php if(count($cats)): ?>
              <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <h3><?php echo e($cat->name, false); ?><h3>
                </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
        </div>
    </section>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\computer-shop\resources\views/welcome.blade.php ENDPATH**/ ?>