<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\product;

class poroductImage extends Model
{
    use HasFactory;
    protected $table="product_images";
    protected $fillable=['image','product_id'];
    public $timestamps = false;
    public function product()
    {
        return $this->belongsTo(product::class, 'product_id');
    }
}
