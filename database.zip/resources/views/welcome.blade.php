@extends('layouts.app')

@section('content')

<div class="container">
    <section>
        <div class="row">
            @if(count($featured_products))
done

            @endif
        </div>
    </section>
    <section>
        <div class="row">
        <h2 class="text-info">Categories</h2>
            @if(count($cats))
              @foreach($cats as $cat)
                <div class="col-md-3 card">
                    <h3 card-header>{{$cat->name}}<h3>
                </div>

              @endforeach

            @endif
        </div>
    </section>
    <hr>
    <section>
        <div class="row">
            <h2 class="text-info">Brands</h2>
            @if(count($cats))
              @foreach($brands as $cat)
                <div class="col-md-3">
                    <h3>{{$cat->name}}<h3>
                </div>

              @endforeach

            @endif
        </div>
    </section>
</div>

@endsection

